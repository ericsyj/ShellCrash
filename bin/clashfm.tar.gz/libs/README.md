用于存放脚本内置工具的脚本

引用方式必须为：

```shell
. "$CRASHDIR"/libs/xxx.sh
```

返回码必须是return x而不能是exit x

此处脚本内容不应包含文字输出和log输出